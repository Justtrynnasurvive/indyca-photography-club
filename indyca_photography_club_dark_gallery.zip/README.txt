IndyCa Photography Club Website

To update the weekly photography:
1. Add your new photo files to the 'photos' folder.
2. Edit index.html and replace the image filenames under <div class="photo-grid">.
3. Save your changes.

To preview locally, open 'index.html' in your browser.
